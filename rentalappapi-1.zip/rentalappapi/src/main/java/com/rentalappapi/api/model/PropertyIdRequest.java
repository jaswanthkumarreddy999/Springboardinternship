package com.rentalappapi.api.model;

public class PropertyIdRequest {
	private int empId;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

}
