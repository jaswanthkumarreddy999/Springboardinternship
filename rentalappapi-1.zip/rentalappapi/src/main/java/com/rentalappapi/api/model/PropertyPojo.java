package com.rentalappapi.api.model;

import java.util.List;

import com.rentalappapi.api.entity.PropertyEntity;

public class PropertyPojo {

	private long totalRecords;

    private List<PropertyEntity> Property;
    
    public long getTotalRecords() {
        return totalRecords;
    }

    public void setTotalRecords(long totalRecords) {
        this.totalRecords = totalRecords;
    }
    
    public List<PropertyEntity> getPropertyList() {
        return Property;
    }
    
    public void setPropertyList(List<PropertyEntity> Property) {
        this.Property = Property;
   }
}

