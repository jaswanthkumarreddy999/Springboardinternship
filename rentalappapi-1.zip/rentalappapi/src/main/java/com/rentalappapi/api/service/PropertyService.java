package com.rentalappapi.api.service;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
 
import com.rentalappapi.api.entity.PropertyEntity;
import com.rentalappapi.api.model.PropertyIdRequest;
import com.rentalappapi.api.model.PropertyPojo;
import com.rentalappapi.api.model.PropertyRequestBody; 
import com.rentalappapi.api.repositories.PropertyRepository;

import java.io.IOException;
import java.io.StringWriter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import org.springframework.stereotype.Service;

@Service
public class PropertyService  {

	@Autowired
	private PropertyRepository PropertyRepository;

	

	public PropertyEntity createProperty(PropertyRequestBody propertyRequestBodyObj) {

		PropertyEntity newProperty = new PropertyEntity();
		newProperty.setTitle(propertyRequestBodyObj.getTitle());
		newProperty.setDescription(propertyRequestBodyObj.getDescription());
		newProperty.setOwnerId(propertyRequestBodyObj.getOwnerId());
		newProperty.setAddress(propertyRequestBodyObj.getAddress());
		newProperty.setCity(propertyRequestBodyObj.getCity());
		newProperty.setState(propertyRequestBodyObj.getState());
		newProperty.setRent_per_month(propertyRequestBodyObj.getRent_per_month());
		newProperty.setCreated_at(propertyRequestBodyObj.getCreated_at());
		
		return PropertyRepository.save(newProperty);		 
	}

	public PropertyEntity updateProperty(PropertyRequestBody propertyRequestBodyObj) {
		PropertyEntity newProperty = new PropertyEntity();
		newProperty.setPropertyId(propertyRequestBodyObj.getPropertyId() ); // must for update
		newProperty.setTitle(propertyRequestBodyObj.getTitle());
		newProperty.setDescription(propertyRequestBodyObj.getDescription());
		newProperty.setOwnerId(propertyRequestBodyObj.getOwnerId());
		newProperty.setAddress(propertyRequestBodyObj.getAddress());
		newProperty.setCity(propertyRequestBodyObj.getCity());
		newProperty.setState(propertyRequestBodyObj.getState());
		newProperty.setRent_per_month(propertyRequestBodyObj.getRent_per_month());
		newProperty.setCreated_at(propertyRequestBodyObj.getCreated_at());
		return PropertyRepository.save(newProperty);		 
	}

	public Page<PropertyEntity> listallusersfromdb(int pageNumber, int size) {
		Pageable pageable = PageRequest.of(pageNumber, size);
		return PropertyRepository.listallusersfromdb(pageable);
	}
 
	public String deleteProperty(PropertyIdRequest user) {
		int PropertyId= user.getEmpId();
		PropertyRepository.deleteById(PropertyId);
		return "Property Deleted";
	}

	public String countNumberOfPropertys() {

		return PropertyRepository.countNumberOfProperty();
	}

	public List getPropertyById(int id) {
		StringWriter sw = new StringWriter();
		ObjectMapper mapper = new ObjectMapper();
		List list = PropertyRepository.findPropertyEntityBypropertyId(id); 
	//List list = PropertyRepository.getPropertyById(id); 
		PropertyPojo propertyPojo = new PropertyPojo();
		propertyPojo.setPropertyList(list);
		propertyPojo.setTotalRecords(1);
		try {
			mapper.writeValue(sw, propertyPojo);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return PropertyRepository.findPropertyEntityBypropertyId(id);		
	}

 

}
