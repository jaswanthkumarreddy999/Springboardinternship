import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
 
 
import { LoginComponent } from './login/login.component';

 

import { PropertyComponent } from './pages/property/property.component';
import { PropertydetailsComponent } from './pages/property/propertydetails/propertydetails.component';
 
 
const routes: Routes = [
  { path: '', redirectTo: '/property', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
    
       
  

  
  { path: 'property', component: PropertyComponent },
  { path: 'property/propertydetails', component: PropertydetailsComponent },
 
 
  ]; 

@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forRoot(routes, { useHash: true })]
})
export class AppRoutingModule { } 