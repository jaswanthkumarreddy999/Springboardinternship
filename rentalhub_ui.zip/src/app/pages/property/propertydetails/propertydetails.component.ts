import { Component, OnInit, AfterViewChecked, ViewChildren, AfterViewInit  } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { NgModel, FormControl } from '@angular/forms';
import 'rxjs/add/operator/map';

declare var $: any;
declare var Materialize: any;

@Component({
  selector: 'app-propertydetails',
  templateUrl: './propertydetails.component.html',
  styleUrls: ['./propertydetails.component.css']
})
export class PropertydetailsComponent implements  OnInit, AfterViewChecked {

 isLoading: boolean = false;     
      editId:string;
      propertyId: string;
     folderName: string;
     parentFolderId: string;
     createdAt: string;
    
     ownerId: "1";
     title: string;
     description:string;
     address:string;
     city: string;
     state: string;
     rent_per_month: string;
     created_at:  string;
   

  router: Router;
   RAGAMusicProfileCode : string;
  @ViewChildren('allTheseThings') things;

    constructor(_router: Router, private _http: Http, private route: ActivatedRoute) {
    this.router = _router;
     
  }

    
 
  private createNewProperty() {
    this.isLoading = true;
    var data22 = {       
     
        "ownerId": "1",
        "title": this.title,
        "description": this.description,
        "address": this.address,
        "city": this.city,
        "state": this.state,
        "rent_per_month": this.rent_per_month,
        "created_at": "2024-11-02 12:50:08"
      
  };
 

    if (this.editId  && this.editId !== ""  && this.editId !== "None") {
     

      data22["propertyId"] = this.editId;
      return this._http.put('http://localhost:8181/rentalhubapi/updateProperty', data22)
        .subscribe(
        res => {
          console.log(res);
          this.isLoading = false;
          var $toastContent = $('<span>Record has been saved successfully!!</span>');
          Materialize.toast($toastContent, 2000);
          this.router.navigate(['/property']);
        },
        err => {
          var $toastContent = $('<span>'+JSON.parse(err["_body"])[0]["errMessage"]+'</span>');
          Materialize.toast($toastContent, 2000);                      
          this.isLoading = false;
        }
        );
    }  else{
      console.log(data22);
            return this._http.post('http://localhost:8181/rentalhubapi/createProperty', data22)
        .subscribe(
        res => {
          console.log(res);
          this.isLoading = false;
          var $toastContent = $('<span>Record has been saved successfully!!</span>');
          Materialize.toast($toastContent, 2000);
          this.router.navigate(['/property']);
        },
        err => {
          var $toastContent = $('<span>'+JSON.parse(err["_body"])[0]["errMessage"]+'</span>');
          Materialize.toast($toastContent, 2000);            
          this.isLoading = false;
        }
        );
    }
  }
  

  public moveNext(event, tab) {
    $('.collapsible').collapsible('open', tab);
  }
ngAfterViewInit() {
    this.things.changes.subscribe(t => {
      $("select").material_select();
    });
     $('#dob').pickadate({
    selectMonths: true,
    selectYears: 100, 
    closeOnSelect: true
  });

  }

  ngAfterViewChecked() {
   
    Materialize.updateTextFields();

  }
  ngOnInit() {
    $("select").material_select();
    $('.collapsible').collapsible({      
      onOpen: function(el) {  Materialize.updateTextFields(); }
    });

    this.route
      .queryParamMap
      .map(params => params.get('session_id') || 'None')
      .subscribe(val => this.editId = val);
    console.log('Hello ---------------------->');
    console.log(this.editId);

    if (this.editId  && this.editId !== ""  && this.editId !== "None") {
      this.isLoading = true;
      return this._http.get('http://localhost:8181/rentalhubapi/getPropertyById/' + this.editId)
        .map((res: Response) => res.json())
        .subscribe(data => {
          var properties = data[0];
      
            this.propertyId= properties.propertyId;
           this.title = properties.title;
          
          this.parentFolderId = properties.ownerId;
          this.createdAt = properties.created_at;
         this.address = properties.address;
         this.city =  properties.city;
        this.state = properties.state;
        this.description = properties.description;
        this.rent_per_month = properties.rent_per_month; 
        this.isLoading = false;
          
        

          $("select").material_select();

      

          Materialize.updateTextFields();
          //debugger;
        },
          err => {
            console.log('Something went wrong!');
            this.isLoading = false;
          });
    }
    //   let m = this.model;
    //   m.valueChanges.subscribe(value => {
    //     Materialize.updateTextFields();
    // });
    Materialize.updateTextFields();
  }
 
  }








