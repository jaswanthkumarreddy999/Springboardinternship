﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'zh', {
    WordCount: '詞數:',
    CharCount: '字數:',
    CharCountWithHTML: '字數 (含HTML)',
    Paragraphs: '段落:',
    pasteWarning: '由於字數達到上限,內容不能粘貼',
    Selected: '已選擇: ',
    title: '統計'
});